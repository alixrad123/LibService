package ir.ghee.model.service;

import ir.ghee.model.entity.User;
import ir.ghee.model.repository.CrudRepository;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class UserService implements ServiceImpl<User,Long> {
    private static UserService userService = new UserService();

    private UserService() {
    }

    public static UserService getUserService() {
        return userService;
    }

    @Override
    public User save(User user) throws Exception {
        try(CrudRepository<User,Long> userDA = new CrudRepository<>()){
            return userDA.save(user);
        }
    }

    @Override
    public User update(User user) throws Exception {
        try(CrudRepository<User,Long> userDA = new CrudRepository<>()){
            return userDA.update(user);
        }
    }

    @Override
    public User delete(Long id) throws Exception {
        try(CrudRepository<User, Long> userDA = new CrudRepository<>()){
            User user = userDA.findById(User.class , 1L);
            user.setStatus(true);
            return userDA.update(user);
        }
    }

    @Override
    public User findById(Long id) throws Exception {
        try(CrudRepository<User,Long> userDA = new CrudRepository<>()){
            return userDA.findById(User.class,id);
        }
    }


    public User findByUsernamePass(String username,String password) throws Exception{
        try(CrudRepository<User,Long> userDA = new CrudRepository<>()) {
            Map<String, Object> param = new HashMap<>();
            param.put("username",username);
            param.put("password",password);
            return userDA.executeQuery("user.findByUsernamePassword",param);
        }
    }

    public User findDelete(String username,String password) throws Exception{
        try(CrudRepository<User,Long> userDA = new CrudRepository<>()) {
            Map<String,Object> param = new HashMap<>();
            param.put("username",username);
            param.put("password",password);
            return userDA.executeQuery("user.findDelete",param);
        }
    }

    @Override
    public List<User> findAll() throws Exception {
        try(CrudRepository<User,Long> userDA = new CrudRepository<>()){
            return userDA.selectAll(User.class);
        }
    }


}

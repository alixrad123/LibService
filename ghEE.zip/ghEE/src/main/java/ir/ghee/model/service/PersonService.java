package ir.ghee.model.service;

import ir.ghee.model.entity.Person;
import ir.ghee.model.repository.CrudRepository;

import java.util.List;

public class PersonService implements ServiceImpl<Person,Long> {
    private static PersonService personService = new PersonService();

    private PersonService() {
    }

    public static PersonService getPersonService() {
        return personService;
    }

    @Override
    public Person save(Person person) throws Exception {
        try(CrudRepository<Person,Long> personDA = new CrudRepository<>()){
            return personDA.save(person);
        }
    }

    @Override
    public Person update(Person person) throws Exception {
        try(CrudRepository<Person,Long> personDA = new CrudRepository<>()){
            return personDA.update(person);
        }
    }

    @Override
    public Person delete(Long id) throws Exception {
        try(CrudRepository<Person, Long> personDA = new CrudRepository<Person, Long>()){
            return personDA.delete(Person.class,id);
        }
    }

    @Override
    public Person findById(Long id) throws Exception {
        try(CrudRepository<Person,Long> personDA = new CrudRepository<>()){
            return personDA.findById(Person.class,id);
        }
    }

    @Override
    public List<Person> findAll() throws Exception {
        try(CrudRepository<Person,Long> personDA = new CrudRepository<>()){
            return personDA.selectAll(Person.class);
        }
    }


}

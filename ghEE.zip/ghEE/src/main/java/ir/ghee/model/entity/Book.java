package ir.ghee.model.entity;

import com.google.gson.Gson;
import jakarta.persistence.*;
import lombok.*;

@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@Builder


@Entity(name = "bookEntity")
@Table(name = "bookTbl")
public class Book {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private int id;

    @Column(length = 100)
    private String name;

    @Column(length = 30)
    private String author;

    public Book(String name, String author) {
        this.name = name;
        this.author = author;
    }

    @Override
    public String toString() {
        return new Gson().toJson(this);
    }


}

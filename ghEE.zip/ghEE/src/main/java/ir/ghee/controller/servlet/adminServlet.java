package ir.ghee.controller.servlet;

import ir.ghee.controller.EntityController;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;

@WebServlet(urlPatterns = "/admin")
public class adminServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        Long id  = Long.parseLong(req.getParameter("id"));
        EntityController userController = new EntityController();
        String answer = userController.removeUser(id);
        if (answer.equals("delete")){
            resp.sendRedirect("/admin.jsp");
        }else{
            resp.getWriter().write(answer);
        }
    }
}

package ir.ghee.controller.servlet;

import ir.ghee.controller.BorrowController;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;

@WebServlet(urlPatterns = "/borrow")
public class borrowServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        req.getSession().getAttribute("password");
        req.getSession().getAttribute("username");
        String username = req.getParameter("username");
        String password = req.getParameter("password");
        if (req.getSession().getAttribute("username").equals(username) && req.getSession().getAttribute("password").equals(password)) {
            int id = Integer.parseInt(req.getParameter("book_id"));
            BorrowController borrowController = new BorrowController();
            if (borrowController.findById(id).equals("Book find")) {
                String borrow = borrowController.save(username, password, id);
                resp.sendRedirect("/acceptBorrow.html");

            } else {
                resp.getWriter().write("enter book id correctly");
            }
        } else {
            resp.getWriter().write("enter your username and pass");
        }
    }
}

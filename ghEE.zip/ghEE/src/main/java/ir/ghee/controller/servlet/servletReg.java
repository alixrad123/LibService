package ir.ghee.controller.servlet;

import ir.ghee.controller.EntityController;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;

@WebServlet(urlPatterns = "/register")
public class servletReg extends HttpServlet {
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException{
        String name = req.getParameter("name");
        String family = req.getParameter("family");
        String nc_code = req.getParameter("nc_code");
        String phoneNumber = req.getParameter("phoneNumber");
        String username = req.getParameter("username");
        String password = req.getParameter("password");

        EntityController entityController = new EntityController();
        String message = entityController.save(name,family,nc_code,phoneNumber,username,password);
        if (message.equals("Saved")){
            resp.sendRedirect("/regMsg.html");
        }else{
            resp.sendRedirect("/error.html");
        }

    }
}

package ir.ghee.controller.servlet;

import ir.ghee.controller.EntityController;
import ir.ghee.controller.UserController;
import ir.ghee.model.service.UserService;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;

@WebServlet(urlPatterns = "/login")
public class logServlet extends HttpServlet {
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String username = req.getParameter("username");
        String password = req.getParameter("password");
        if (username.equals("admin") && password.equals("admin")) {
            req.getSession().setAttribute("role", "admin");
            resp.sendRedirect("/admin.jsp");
        } else {
            EntityController entityController = new EntityController();
            if (entityController.findByUserPass(username, password) != null) {
                UserController uSerController = new UserController();
                if (uSerController.findDelete(username, password).equals("user deleted")) {
                    resp.getWriter().write("User is deleted");
                } else {
                    req.getSession().setAttribute("username", username);
                    req.getSession().setAttribute("password", password);
                    req.getRequestDispatcher("/panel.jsp").forward(req, resp);
                }
            } else {
                resp.getWriter().write("Error from login");
            }
        }


    }
}
